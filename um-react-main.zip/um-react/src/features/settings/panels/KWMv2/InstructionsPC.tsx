import { Text } from '@chakra-ui/react';

export function InstructionsPC() {
  return (
    <>
      <Text>使用 Windows 客户端下载的文件不需要导入密钥。</Text>
    </>
  );
}
