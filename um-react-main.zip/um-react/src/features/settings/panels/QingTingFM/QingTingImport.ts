// TODO: Popup dialog for QingTing instructions
