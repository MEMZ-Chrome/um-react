import { VQuote } from '~/components/HelpText/VQuote';

export function SegmentTopNavSettings() {
  return (
    <>
      点击顶部的<VQuote>设置</VQuote>
    </>
  );
}
